#include <iostream>
#include "event.h"
using namespace std;
/*********************************************************************
** Function:~event
** Description: empty event destructor to silence the complier warnings
** Parameters: none
** Pre-Conditions: none
** Post-Conditions: an event is destroyed
*********************************************************************/
Event::~Event(){}