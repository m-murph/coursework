
#include <iostream>
//#include "card.h"
#include "deck.h"

using namespace std;

int main(){
    Deck deck;
    deck.shuffle();
    deck.print();
}
