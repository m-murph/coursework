#include "dictionary.h"
#include <iostream>
using namespace std;

/*
	Test the functionality of the dictionary
*/
int main() {

	Dictionary d1;
	d1.add_word("island", "ilande", "ylonde");
	d1.add_word("jeopardy", "yeopardie", "ieoperde");

	return 0;
}
