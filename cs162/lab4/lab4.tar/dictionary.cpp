#include "dictionary.h"
using namespace std;

// default constructor
Dictionary::Dictionary() {
	cout << "Default constructor invoked." << endl;
	index = 0; // start with 0 entries
	// set the default number of alternate spellings to 0
	for (int i = 0; i < MAX_ENTRIES; i++) {
		entries[i].alt_spellings = NULL;
		entries[i].num_alt_spellings = 0;
	}
}

// copy constructor
Dictionary::Dictionary(const Dictionary& old_obj) {
	cout << "Copy constructor invoked." << endl;

	// your code will go here
}

// assignment operator overload
Dictionary& Dictionary::operator=(const Dictionary& old_obj) {
	cout << "Assignment operator overload invoked." << endl;

	// your code will go here

	return *this;
}

// deallocate all dynamic memory
Dictionary::~Dictionary() {
	cout << "Destructor invoked." << endl;
	for (int i = 0; i < MAX_ENTRIES; i++)
		delete [] entries[i].alt_spellings;
}

// add a word to the dictionary (along with its two alternate spellings)
void Dictionary::add_word(string new_word, string alt_1, string alt_2) {
	entry *tmp = &entries[index];
	tmp->word = new_word;
	tmp->num_alt_spellings = 2;
	tmp->alt_spellings = new string[tmp->num_alt_spellings];
	tmp->alt_spellings[0] = alt_1;
	tmp->alt_spellings[1] = alt_2;
	index++;
}

